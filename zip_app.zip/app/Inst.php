<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inst extends Model
{
    //
	protected $guarded = ["id"];

}

