<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Event;
    
    //=======================================================================
    class EventsController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [events]--
				// ----------------------------------------------------
				$event = DB::table("events")
				->leftJoin("insts","insts.id", "=", "events.insts_id")
				->leftJoin("users","users.id", "=", "events.inst_users_id")
				->orWhere("events.title", "LIKE", "%$keyword%")->orWhere("events.insts_id", "LIKE", "%$keyword%")->orWhere("events.start_time", "LIKE", "%$keyword%")->orWhere("events.end_time", "LIKE", "%$keyword%")->orWhere("events.dtls", "LIKE", "%$keyword%")->orWhere("events.img", "LIKE", "%$keyword%")->orWhere("events.capacity", "LIKE", "%$keyword%")->orWhere("events.inst_users_id", "LIKE", "%$keyword%")->orWhere("insts.inst_name", "LIKE", "%$keyword%")->orWhere("insts.nations_id", "LIKE", "%$keyword%")->orWhere("insts.life", "LIKE", "%$keyword%")->orWhere("users.type", "LIKE", "%$keyword%")->orWhere("users.firstname", "LIKE", "%$keyword%")->orWhere("users.lastname", "LIKE", "%$keyword%")->orWhere("users.email", "LIKE", "%$keyword%")->orWhere("users.password", "LIKE", "%$keyword%")->orWhere("users.life", "LIKE", "%$keyword%")->orWhere("users.remember_token", "LIKE", "%$keyword%")->select("*")->addSelect("events.id")->paginate($perPage);
            } else {
                    //$event = Event::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [events]--
				// ----------------------------------------------------
				$event = DB::table("events")
				->leftJoin("insts","insts.id", "=", "events.insts_id")
				->leftJoin("users","users.id", "=", "events.inst_users_id")
				->select("*")->addSelect("events.id")->paginate($perPage);              
            }          
            return view("event.index", compact("event"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("event.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"title" => "required", //string('title')
				"insts_id" => "required|integer", //bigInteger('insts_id')
				"date" => "required|date", //date('date')
				"start_time" => "required", //time('start_time')
				"end_time" => "required", //time('end_time')
				"dtls" => "required", //string('dtls')
				"img" => "required", //string('img')
				"capacity" => "required|integer", //integer('capacity')
				"inst_users_id" => "required|integer", //bigInteger('inst_users_id')

            ]);
            $requestData = $request->all();
            
            Event::create($requestData);
    
            return redirect("event")->with("flash_message", "event added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$event = Event::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [events]--
				// ----------------------------------------------------
				$event = DB::table("events")
				->leftJoin("insts","insts.id", "=", "events.insts_id")
				->leftJoin("users","users.id", "=", "events.inst_users_id")
				->select("*")->addSelect("events.id")->where("events.id",$id)->first();
            return view("event.show", compact("event"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $event = Event::findOrFail($id);
    
            return view("event.edit", compact("event"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"title" => "required", //string('title')
				"insts_id" => "required|integer", //bigInteger('insts_id')
				"date" => "required|date", //date('date')
				"start_time" => "required", //time('start_time')
				"end_time" => "required", //time('end_time')
				"dtls" => "required", //string('dtls')
				"img" => "required", //string('img')
				"capacity" => "required|integer", //integer('capacity')
				"inst_users_id" => "required|integer", //bigInteger('inst_users_id')

            ]);
            $requestData = $request->all();
            
            $event = Event::findOrFail($id);
            $event->update($requestData);
    
            return redirect("event")->with("flash_message", "event updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Event::destroy($id);
    
            return redirect("event")->with("flash_message", "event deleted!");
        }
    }
    //=======================================================================
    
    