<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Nation;
    
    //=======================================================================
    class NationsController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [nations]--
				// ----------------------------------------------------
				$nation = DB::table("nations")
				->orWhere("nations.region", "LIKE", "%$keyword%")->orWhere("nations.country", "LIKE", "%$keyword%")->select("*")->addSelect("nations.id")->paginate($perPage);
            } else {
                    //$nation = Nation::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [nations]--
				// ----------------------------------------------------
				$nation = DB::table("nations")
				->select("*")->addSelect("nations.id")->paginate($perPage);              
            }          
            return view("nation.index", compact("nation"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("nation.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"region" => "required", //string('region')
				"country" => "required", //string('country')

            ]);
            $requestData = $request->all();
            
            Nation::create($requestData);
    
            return redirect("nation")->with("flash_message", "nation added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$nation = Nation::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [nations]--
				// ----------------------------------------------------
				$nation = DB::table("nations")
				->select("*")->addSelect("nations.id")->where("nations.id",$id)->first();
            return view("nation.show", compact("nation"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $nation = Nation::findOrFail($id);
    
            return view("nation.edit", compact("nation"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"region" => "required", //string('region')
				"country" => "required", //string('country')

            ]);
            $requestData = $request->all();
            
            $nation = Nation::findOrFail($id);
            $nation->update($requestData);
    
            return redirect("nation")->with("flash_message", "nation updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Nation::destroy($id);
    
            return redirect("nation")->with("flash_message", "nation deleted!");
        }
    }
    //=======================================================================
    
    