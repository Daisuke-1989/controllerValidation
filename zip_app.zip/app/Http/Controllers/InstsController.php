<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Inst;
    
    //=======================================================================
    class InstsController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [insts]--
				// ----------------------------------------------------
				$inst = DB::table("insts")
				->leftJoin("nations","nations.id", "=", "insts.nations_id")
				->orWhere("insts.inst_name", "LIKE", "%$keyword%")->orWhere("insts.nations_id", "LIKE", "%$keyword%")->orWhere("insts.life", "LIKE", "%$keyword%")->orWhere("nations.region", "LIKE", "%$keyword%")->orWhere("nations.country", "LIKE", "%$keyword%")->select("*")->addSelect("insts.id")->paginate($perPage);
            } else {
                    //$inst = Inst::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [insts]--
				// ----------------------------------------------------
				$inst = DB::table("insts")
				->leftJoin("nations","nations.id", "=", "insts.nations_id")
				->select("*")->addSelect("insts.id")->paginate($perPage);              
            }          
            return view("inst.index", compact("inst"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("inst.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"inst_name" => "required", //string('inst_name')
				"nations_id" => "required|integer", //bigInteger('nations_id')
				"life" => "required|integer", //integer('life')

            ]);
            $requestData = $request->all();
            
            Inst::create($requestData);
    
            return redirect("inst")->with("flash_message", "inst added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$inst = Inst::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [insts]--
				// ----------------------------------------------------
				$inst = DB::table("insts")
				->leftJoin("nations","nations.id", "=", "insts.nations_id")
				->select("*")->addSelect("insts.id")->where("insts.id",$id)->first();
            return view("inst.show", compact("inst"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $inst = Inst::findOrFail($id);
    
            return view("inst.edit", compact("inst"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"inst_name" => "required", //string('inst_name')
				"nations_id" => "required|integer", //bigInteger('nations_id')
				"life" => "required|integer", //integer('life')

            ]);
            $requestData = $request->all();
            
            $inst = Inst::findOrFail($id);
            $inst->update($requestData);
    
            return redirect("inst")->with("flash_message", "inst updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Inst::destroy($id);
    
            return redirect("inst")->with("flash_message", "inst deleted!");
        }
    }
    //=======================================================================
    
    