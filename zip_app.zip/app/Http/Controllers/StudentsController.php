<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Student;
    
    //=======================================================================
    class StudentsController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [students]--
				// ----------------------------------------------------
				$student = DB::table("students")
				->leftJoin("users","users.id", "=", "students.id")
				->leftJoin("nations","nations.id", "=", "students.nations_id")
				->orWhere("students.nations_id", "LIKE", "%$keyword%")->orWhere("students.year", "LIKE", "%$keyword%")->orWhere("users.type", "LIKE", "%$keyword%")->orWhere("users.firstname", "LIKE", "%$keyword%")->orWhere("users.lastname", "LIKE", "%$keyword%")->orWhere("users.email", "LIKE", "%$keyword%")->orWhere("users.password", "LIKE", "%$keyword%")->orWhere("users.life", "LIKE", "%$keyword%")->orWhere("users.remember_token", "LIKE", "%$keyword%")->orWhere("nations.region", "LIKE", "%$keyword%")->orWhere("nations.country", "LIKE", "%$keyword%")->select("*")->addSelect("students.id")->paginate($perPage);
            } else {
                    //$student = Student::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [students]--
				// ----------------------------------------------------
				$student = DB::table("students")
				->leftJoin("users","users.id", "=", "students.id")
				->leftJoin("nations","nations.id", "=", "students.nations_id")
				->select("*")->addSelect("students.id")->paginate($perPage);              
            }          
            return view("student.index", compact("student"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("student.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"id" => "required|integer", //bigInteger('id')
				"nations_id" => "required|integer", //bigInteger('nations_id')
				"year" => "required", //string('year')

            ]);
            $requestData = $request->all();
            
            Student::create($requestData);
    
            return redirect("student")->with("flash_message", "student added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$student = Student::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [students]--
				// ----------------------------------------------------
				$student = DB::table("students")
				->leftJoin("users","users.id", "=", "students.id")
				->leftJoin("nations","nations.id", "=", "students.nations_id")
				->select("*")->addSelect("students.id")->where("students.id",$id)->first();
            return view("student.show", compact("student"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $student = Student::findOrFail($id);
    
            return view("student.edit", compact("student"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"id" => "required|integer", //bigInteger('id')
				"nations_id" => "required|integer", //bigInteger('nations_id')
				"year" => "required", //string('year')

            ]);
            $requestData = $request->all();
            
            $student = Student::findOrFail($id);
            $student->update($requestData);
    
            return redirect("student")->with("flash_message", "student updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Student::destroy($id);
    
            return redirect("student")->with("flash_message", "student deleted!");
        }
    }
    //=======================================================================
    
    