<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Term;
    
    //=======================================================================
    class TermsController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [terms]--
				// ----------------------------------------------------
				$term = DB::table("terms")
				->leftJoin("querys","querys.terms_id", "=", "terms.id")
				->orWhere("terms.term", "LIKE", "%$keyword%")->orWhere("querys.events_id", "LIKE", "%$keyword%")->orWhere("querys.terms_id", "LIKE", "%$keyword%")->orWhere("querys.students_id", "LIKE", "%$keyword%")->orWhere("querys.dtls", "LIKE", "%$keyword%")->select("*")->addSelect("terms.id")->paginate($perPage);
            } else {
                    //$term = Term::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [terms]--
				// ----------------------------------------------------
				$term = DB::table("terms")
				->leftJoin("querys","querys.terms_id", "=", "terms.id")
				->select("*")->addSelect("terms.id")->paginate($perPage);              
            }          
            return view("term.index", compact("term"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("term.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"term" => "required", //string('term')

            ]);
            $requestData = $request->all();
            
            Term::create($requestData);
    
            return redirect("term")->with("flash_message", "term added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$term = Term::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [terms]--
				// ----------------------------------------------------
				$term = DB::table("terms")
				->leftJoin("querys","querys.terms_id", "=", "terms.id")
				->select("*")->addSelect("terms.id")->where("terms.id",$id)->first();
            return view("term.show", compact("term"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $term = Term::findOrFail($id);
    
            return view("term.edit", compact("term"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"term" => "required", //string('term')

            ]);
            $requestData = $request->all();
            
            $term = Term::findOrFail($id);
            $term->update($requestData);
    
            return redirect("term")->with("flash_message", "term updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Term::destroy($id);
    
            return redirect("term")->with("flash_message", "term deleted!");
        }
    }
    //=======================================================================
    
    