<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Query;
    
    //=======================================================================
    class QuerysController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [querys]--
				// ----------------------------------------------------
				$query = DB::table("querys")
				->leftJoin("events","events.id", "=", "querys.events_id")
				->leftJoin("users","users.id", "=", "querys.students_id")
				->orWhere("querys.events_id", "LIKE", "%$keyword%")->orWhere("querys.terms_id", "LIKE", "%$keyword%")->orWhere("querys.students_id", "LIKE", "%$keyword%")->orWhere("querys.dtls", "LIKE", "%$keyword%")->orWhere("events.title", "LIKE", "%$keyword%")->orWhere("events.insts_id", "LIKE", "%$keyword%")->orWhere("events.start_time", "LIKE", "%$keyword%")->orWhere("events.end_time", "LIKE", "%$keyword%")->orWhere("events.dtls", "LIKE", "%$keyword%")->orWhere("events.img", "LIKE", "%$keyword%")->orWhere("events.capacity", "LIKE", "%$keyword%")->orWhere("events.inst_users_id", "LIKE", "%$keyword%")->orWhere("users.type", "LIKE", "%$keyword%")->orWhere("users.firstname", "LIKE", "%$keyword%")->orWhere("users.lastname", "LIKE", "%$keyword%")->orWhere("users.email", "LIKE", "%$keyword%")->orWhere("users.password", "LIKE", "%$keyword%")->orWhere("users.life", "LIKE", "%$keyword%")->orWhere("users.remember_token", "LIKE", "%$keyword%")->select("*")->addSelect("querys.id")->paginate($perPage);
            } else {
                    //$query = Query::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [querys]--
				// ----------------------------------------------------
				$query = DB::table("querys")
				->leftJoin("events","events.id", "=", "querys.events_id")
				->leftJoin("users","users.id", "=", "querys.students_id")
				->select("*")->addSelect("querys.id")->paginate($perPage);              
            }          
            return view("query.index", compact("query"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("query.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"events_id" => "required|integer", //bigInteger('events_id')
				"terms_id" => "required|integer", //bigInteger('terms_id')
				"students_id" => "required|integer", //bigInteger('students_id')
				"dtls" => "required", //string('dtls')

            ]);
            $requestData = $request->all();
            
            Query::create($requestData);
    
            return redirect("query")->with("flash_message", "query added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$query = Query::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [querys]--
				// ----------------------------------------------------
				$query = DB::table("querys")
				->leftJoin("events","events.id", "=", "querys.events_id")
				->leftJoin("users","users.id", "=", "querys.students_id")
				->select("*")->addSelect("querys.id")->where("querys.id",$id)->first();
            return view("query.show", compact("query"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $query = Query::findOrFail($id);
    
            return view("query.edit", compact("query"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"events_id" => "required|integer", //bigInteger('events_id')
				"terms_id" => "required|integer", //bigInteger('terms_id')
				"students_id" => "required|integer", //bigInteger('students_id')
				"dtls" => "required", //string('dtls')

            ]);
            $requestData = $request->all();
            
            $query = Query::findOrFail($id);
            $query->update($requestData);
    
            return redirect("query")->with("flash_message", "query updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Query::destroy($id);
    
            return redirect("query")->with("flash_message", "query deleted!");
        }
    }
    //=======================================================================
    
    