<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validate;
use DB;
use App\Level;
    
    //=======================================================================
    class LevelsController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\View\View
         */
        public function index(Request $request)
        {
            $keyword = $request->get("search");
            $perPage = 25;
    
            if (!empty($keyword)) {
                
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [levels]--
				// ----------------------------------------------------
				$level = DB::table("levels")
				->orWhere("levels.level", "LIKE", "%$keyword%")->select("*")->addSelect("levels.id")->paginate($perPage);
            } else {
                    //$level = Level::paginate($perPage);
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [levels]--
				// ----------------------------------------------------
				$level = DB::table("levels")
				->select("*")->addSelect("levels.id")->paginate($perPage);              
            }          
            return view("level.index", compact("level"));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\View\View
         */
        public function create()
        {
            return view("level.create");
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function store(Request $request)
        {
            $this->validate($request, [
				"level" => "required", //string('level')

            ]);
            $requestData = $request->all();
            
            Level::create($requestData);
    
            return redirect("level")->with("flash_message", "level added!");
        }
    
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function show($id)
        {
            //$level = Level::findOrFail($id);
            
				// ----------------------------------------------------
				// -- QueryBuilder: SELECT [levels]--
				// ----------------------------------------------------
				$level = DB::table("levels")
				->select("*")->addSelect("levels.id")->where("levels.id",$id)->first();
            return view("level.show", compact("level"));
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         *
         * @return \Illuminate\View\View
         */
        public function edit($id)
        {
            $level = Level::findOrFail($id);
    
            return view("level.edit", compact("level"));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  int  $id
         * @param \Illuminate\Http\Request $request
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function update(Request $request, $id)
        {
            $this->validate($request, [
				"level" => "required", //string('level')

            ]);
            $requestData = $request->all();
            
            $level = Level::findOrFail($id);
            $level->update($requestData);
    
            return redirect("level")->with("flash_message", "level updated!");
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         *
         * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
         */
        public function destroy($id)
        {
            Level::destroy($id);
    
            return redirect("level")->with("flash_message", "level deleted!");
        }
    }
    //=======================================================================
    
    