<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nation extends Model
{
    //
	protected $guarded = ["id"];
	protected $guarded = ["id"];

}

