<?php
use Illuminate\Http\Response;

//default
Route::get("/", function () {
    return view("welcome");
});
//Demo (Delete after site publish.)
Route::get("/tables_check_view_html",function(){
    return view("tables_check_view_html");
});

//=======================================================================
//index
Route::get("user/", "UsersController@index");
//create
Route::get("user/create", "UsersController@create");
//show
Route::get("user/{id}", "UsersController@show");
//store
Route::post("user/store", "UsersController@store");
//edit
Route::get("user/{id}/edit", "UsersController@edit");
//update
Route::put("user/{id}", "UsersController@update");
//destroy
Route::delete("user/{id}", "UsersController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("event/", "EventsController@index");
//create
Route::get("event/create", "EventsController@create");
//show
Route::get("event/{id}", "EventsController@show");
//store
Route::post("event/store", "EventsController@store");
//edit
Route::get("event/{id}/edit", "EventsController@edit");
//update
Route::put("event/{id}", "EventsController@update");
//destroy
Route::delete("event/{id}", "EventsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("query/", "QuerysController@index");
//create
Route::get("query/create", "QuerysController@create");
//show
Route::get("query/{id}", "QuerysController@show");
//store
Route::post("query/store", "QuerysController@store");
//edit
Route::get("query/{id}/edit", "QuerysController@edit");
//update
Route::put("query/{id}", "QuerysController@update");
//destroy
Route::delete("query/{id}", "QuerysController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("inst/", "InstsController@index");
//create
Route::get("inst/create", "InstsController@create");
//show
Route::get("inst/{id}", "InstsController@show");
//store
Route::post("inst/store", "InstsController@store");
//edit
Route::get("inst/{id}/edit", "InstsController@edit");
//update
Route::put("inst/{id}", "InstsController@update");
//destroy
Route::delete("inst/{id}", "InstsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("student/", "StudentsController@index");
//create
Route::get("student/create", "StudentsController@create");
//show
Route::get("student/{id}", "StudentsController@show");
//store
Route::post("student/store", "StudentsController@store");
//edit
Route::get("student/{id}/edit", "StudentsController@edit");
//update
Route::put("student/{id}", "StudentsController@update");
//destroy
Route::delete("student/{id}", "StudentsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("nation/", "NationsController@index");
//create
Route::get("nation/create", "NationsController@create");
//show
Route::get("nation/{id}", "NationsController@show");
//store
Route::post("nation/store", "NationsController@store");
//edit
Route::get("nation/{id}/edit", "NationsController@edit");
//update
Route::put("nation/{id}", "NationsController@update");
//destroy
Route::delete("nation/{id}", "NationsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("inst_user/", "InstUsersController@index");
//create
Route::get("inst_user/create", "InstUsersController@create");
//show
Route::get("inst_user/{id}", "InstUsersController@show");
//store
Route::post("inst_user/store", "InstUsersController@store");
//edit
Route::get("inst_user/{id}/edit", "InstUsersController@edit");
//update
Route::put("inst_user/{id}", "InstUsersController@update");
//destroy
Route::delete("inst_user/{id}", "InstUsersController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("book/", "BooksController@index");
//create
Route::get("book/create", "BooksController@create");
//show
Route::get("book/{id}", "BooksController@show");
//store
Route::post("book/store", "BooksController@store");
//edit
Route::get("book/{id}/edit", "BooksController@edit");
//update
Route::put("book/{id}", "BooksController@update");
//destroy
Route::delete("book/{id}", "BooksController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("term/", "TermsController@index");
//create
Route::get("term/create", "TermsController@create");
//show
Route::get("term/{id}", "TermsController@show");
//store
Route::post("term/store", "TermsController@store");
//edit
Route::get("term/{id}/edit", "TermsController@edit");
//update
Route::put("term/{id}", "TermsController@update");
//destroy
Route::delete("term/{id}", "TermsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("password_reset/", "PasswordResetsController@index");
//create
Route::get("password_reset/create", "PasswordResetsController@create");
//show
Route::get("password_reset/{id}", "PasswordResetsController@show");
//store
Route::post("password_reset/store", "PasswordResetsController@store");
//edit
Route::get("password_reset/{id}/edit", "PasswordResetsController@edit");
//update
Route::put("password_reset/{id}", "PasswordResetsController@update");
//destroy
Route::delete("password_reset/{id}", "PasswordResetsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("level/", "LevelsController@index");
//create
Route::get("level/create", "LevelsController@create");
//show
Route::get("level/{id}", "LevelsController@show");
//store
Route::post("level/store", "LevelsController@store");
//edit
Route::get("level/{id}/edit", "LevelsController@edit");
//update
Route::put("level/{id}", "LevelsController@update");
//destroy
Route::delete("level/{id}", "LevelsController@destroy");
//=======================================================================

//=======================================================================
//index
Route::get("subject/", "SubjectsController@index");
//create
Route::get("subject/create", "SubjectsController@create");
//show
Route::get("subject/{id}", "SubjectsController@show");
//store
Route::post("subject/store", "SubjectsController@store");
//edit
Route::get("subject/{id}/edit", "SubjectsController@edit");
//update
Route::put("subject/{id}", "SubjectsController@update");
//destroy
Route::delete("subject/{id}", "SubjectsController@destroy");
//=======================================================================
