
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">nation {{ $nation->id }}</div>
                            <div class="panel-body">

                                <a href="{{ url("nation") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("nation") ."/". $nation->id . "/edit" }}" title="Edit nation"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/nation/{{ $nation->id }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$nation->id}} </td></tr>
										<tr><th>id</th><td>{{$nation->id}} </td></tr>
										<tr><th>region</th><td>{{$nation->region}} </td></tr>
										<tr><th>country</th><td>{{$nation->country}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    