
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">event {{ $event->id }}</div>
                            <div class="panel-body">

                                <a href="{{ url("event") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("event") ."/". $event->id . "/edit" }}" title="Edit event"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/event/{{ $event->id }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$event->id}} </td></tr>
										<tr><th>title</th><td>{{$event->title}} </td></tr>
										<tr><th>insts_id</th><td>{{$event->insts_id}} </td></tr>
										<tr><th>date</th><td>{{$event->date}} </td></tr>
										<tr><th>start_time</th><td>{{$event->start_time}} </td></tr>
										<tr><th>end_time</th><td>{{$event->end_time}} </td></tr>
										<tr><th>dtls</th><td>{{$event->dtls}} </td></tr>
										<tr><th>img</th><td>{{$event->img}} </td></tr>
										<tr><th>capacity</th><td>{{$event->capacity}} </td></tr>
										<tr><th>inst_users_id</th><td>{{$event->inst_users_id}} </td></tr>
										<tr><th>inst_name</th><td>{{$event->inst_name}} </td></tr>
										<tr><th>nations_id</th><td>{{$event->nations_id}} </td></tr>
										<tr><th>life</th><td>{{$event->life}} </td></tr>
										<tr><th>type</th><td>{{$event->type}} </td></tr>
										<tr><th>firstname</th><td>{{$event->firstname}} </td></tr>
										<tr><th>lastname</th><td>{{$event->lastname}} </td></tr>
										<tr><th>email</th><td>{{$event->email}} </td></tr>
										<tr><th>email_verified_at</th><td>{{$event->email_verified_at}} </td></tr>
										<tr><th>password</th><td>{{$event->password}} </td></tr>
										<tr><th>life</th><td>{{$event->life}} </td></tr>
										<tr><th>remember_token</th><td>{{$event->remember_token}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    