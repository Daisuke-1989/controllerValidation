
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Tables</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://getbootstrap.com/docs/4.0/examples/dashboard/dashboard.css" rel="stylesheet">
</head>

<body>
<h1>Tables</h1>
    <div class="container-fluid">
        <div class="row">
            
                


                <!-- table[Start] --><div class="col-md-3"><h2 class="info">users</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id');
</td><td></td></tr><tr><td>2</td><td>integer('type');
</td><td></td></tr><tr><td>3</td><td>string('firstname');
</td><td></td></tr><tr><td>4</td><td>string('lastname');
</td><td></td></tr><tr><td>5</td><td>string('email');
</td><td></td></tr><tr><td>6</td><td>timestamp('email_verified_at')->nullable();
</td><td></td></tr><tr><td>7</td><td>string('password');
</td><td></td></tr><tr><td>8</td><td>integer('life');
</td><td></td></tr><tr><td>9</td><td>string('remember_token',100);
</td><td></td></tr><tr><td>10</td><td>timestamps();
</td><td></td></tr><tr><td>11</td><td>softDeletes();
</td><td></td></tr><tr><td>12</td><td>unique('email');
</td><td></td></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">events</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>string('title');
</td><td></td></tr><tr><td>3</td><td>bigInteger('insts_id')->unsigned();
</td><td></td></tr><tr><td>4</td><td>date('date');
</td><td></td></tr><tr><td>5</td><td>time('start_time');
</td><td></td></tr><tr><td>6</td><td>time('end_time');
</td><td></td></tr><tr><td>7</td><td>string('dtls');
</td><td></td></tr><tr><td>8</td><td>string('img');
</td><td></td></tr><tr><td>9</td><td>integer('capacity');
</td><td></td></tr><tr><td>10</td><td>bigInteger('inst_users_id')->unsigned();
</td><td></td></tr><tr><td>11</td><td>timestamps();
</td><td></td></tr><tr><td>12</td><td>softDeletes();
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("insts_id")<span class="text-danger">->references("id")->on("insts");</span>
</td></tr></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("inst_users_id")<span class="text-danger">->references("id")->on("users");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">querys</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>bigInteger('events_id')->unsigned();
</td><td></td></tr><tr><td>3</td><td>bigInteger('terms_id')->unsigned();
</td><td></td></tr><tr><td>4</td><td>bigInteger('students_id')->unsigned();
</td><td></td></tr><tr><td>5</td><td>string('dtls');
</td><td></td></tr><tr><td>6</td><td>timestamps();
</td><td></td></tr><tr><td>7</td><td>softDeletes();
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("events_id")<span class="text-danger">->references("id")->on("events");</span>
</td></tr></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("students_id")<span class="text-danger">->references("id")->on("users");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">insts</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>string('inst_name');
</td><td></td></tr><tr><td>3</td><td>bigInteger('nations_id')->unsigned();
</td><td></td></tr><tr><td>4</td><td>integer('life');
</td><td></td></tr><tr><td>5</td><td>timestamps();
</td><td></td></tr><tr><td>6</td><td>softDeletes();
</td><td></td></tr><tr><td>7</td><td>unique('inst_name');
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("nations_id")<span class="text-danger">->references("id")->on("nations");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">students</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigInteger('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>bigInteger('nations_id')->unsigned();
</td><td></td></tr><tr><td>3</td><td>string('year');
</td><td></td></tr><tr><td>4</td><td>timestamps();
</td><td></td></tr><tr><td>5</td><td>softDeletes();
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("id")<span class="text-danger">->references("id")->on("users");</span>
</td></tr></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("nations_id")<span class="text-danger">->references("id")->on("nations");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">nations</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id');
</td><td></td></tr><tr><td>2</td><td>bigIncrements('id');
</td><td></td></tr><tr><td>3</td><td>string('region');
</td><td></td></tr><tr><td>4</td><td>string('country');
</td><td></td></tr><tr><td>5</td><td>timestamps();
</td><td></td></tr><tr><td>6</td><td>softDeletes();
</td><td></td></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">inst_users</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigInteger('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>bigInteger('inst_id')->unsigned();
</td><td></td></tr><tr><td>3</td><td>string('j_title');
</td><td></td></tr><tr><td>4</td><td>string('dept');
</td><td></td></tr><tr><td>5</td><td>timestamps();
</td><td></td></tr><tr><td>6</td><td>softDeletes();
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("id")<span class="text-danger">->references("id")->on("users");</span>
</td></tr></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("inst_id")<span class="text-danger">->references("id")->on("insts");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">books</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>bigInteger('events_id')->unsigned();
</td><td></td></tr><tr><td>3</td><td>bigInteger('students_id')->unsigned();
</td><td></td></tr><tr><td>4</td><td>integer('CXL');
</td><td></td></tr><tr><td>5</td><td>timestamps();
</td><td></td></tr><tr><td>6</td><td>softDeletes();
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("events_id")<span class="text-danger">->references("id")->on("events");</span>
</td></tr></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("students_id")<span class="text-danger">->references("id")->on("users");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">terms</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id')->unsigned();
</td><td></td></tr><tr><td>2</td><td>string('term');
</td><td></td></tr><tr><td>3</td><td>timestamps();
</td><td></td></tr><tr><td>4</td><td>softDeletes();
</td><td></td></tr><tr><td class="bg-secondary text-white">FK</td><td colspan="2">$table->foreign("id")<span class="text-danger">->references("terms_id")->on("querys");</span>
</td></tr></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">password_resets</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>string('email');
</td><td></td></tr><tr><td>2</td><td>string('token');
</td><td></td></tr><tr><td>3</td><td>timestamps();
</td><td></td></tr><tr><td>4</td><td>softDeletes();
</td><td></td></tr><tr><td>5</td><td>index('email');
</td><td></td></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">levels</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id');
</td><td></td></tr><tr><td>2</td><td>string('level');
</td><td></td></tr><tr><td>3</td><td>timestamps();
</td><td></td></tr><tr><td>4</td><td>softDeletes();
</td><td></td></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --><div class="col-md-3"><h2 class="info">subjects</h2><h5>[ ]</h5><div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                            <tr class="bg-primary text-white">
                                <th>-</th>
                                <th>Name(Type Size)</th>
                                <th>Comment</th>
                            </tr>
                            </thead>

                            <tbody>
                            <!-- TR --><tr><td>1</td><td>bigIncrements('id');
</td><td></td></tr><tr><td>2</td><td>string('subject');
</td><td></td></tr><tr><td>3</td><td>timestamps();
</td><td></td></tr><tr><td>4</td><td>softDeletes();
</td><td></td></tr><!-- TR -->
                            </tbody>

                        </table>
                    </div>
                     </div>
                    <!-- table[end] --> </main>
        </div>
    </div>
</body>

</html>
