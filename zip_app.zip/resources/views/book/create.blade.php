
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">Create New book</div>
                            <div class="panel-body">
                                <a href="{{ url("/book") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <br />
                                <br />

                                @if ($errors->any())
                                    <ul class="alert alert-danger">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                @endif
                                
                                
                                <form method="POST" action="/book/store" class="form-horizontal">
                                    {{ csrf_field() }}

    										<div class="form-group">
                                        <label for="events_id" class="col-md-4 control-label">events_id: </label>
                                        <div class="col-md-6">
                                            <input class="form-control" required="required" name="events_id" type="text" id="events_id" value="{{old('events_id')}}">
                                        </div>
                                    </div>
										<div class="form-group">
                                        <label for="students_id" class="col-md-4 control-label">students_id: </label>
                                        <div class="col-md-6">
                                            <input class="form-control" required="required" name="students_id" type="text" id="students_id" value="{{old('students_id')}}">
                                        </div>
                                    </div>
										<div class="form-group">
                                        <label for="CXL" class="col-md-4 control-label">CXL: </label>
                                        <div class="col-md-6">
                                            <input class="form-control" required="required" name="CXL" type="text" id="CXL" value="{{old('CXL')}}">
                                        </div>
                                    </div>
                    
                                    <div class="form-group">
                                        <div class="col-md-offset-4 col-md-4">
                                            <input class="btn btn-primary" type="submit" value="Create">
                                        </div>
                                    </div>     
                                </form>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    