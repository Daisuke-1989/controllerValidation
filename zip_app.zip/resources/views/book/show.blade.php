
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">book {{ $book->id }}</div>
                            <div class="panel-body">

                                <a href="{{ url("book") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("book") ."/". $book->id . "/edit" }}" title="Edit book"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/book/{{ $book->id }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$book->id}} </td></tr>
										<tr><th>events_id</th><td>{{$book->events_id}} </td></tr>
										<tr><th>students_id</th><td>{{$book->students_id}} </td></tr>
										<tr><th>CXL</th><td>{{$book->CXL}} </td></tr>
										<tr><th>title</th><td>{{$book->title}} </td></tr>
										<tr><th>insts_id</th><td>{{$book->insts_id}} </td></tr>
										<tr><th>date</th><td>{{$book->date}} </td></tr>
										<tr><th>start_time</th><td>{{$book->start_time}} </td></tr>
										<tr><th>end_time</th><td>{{$book->end_time}} </td></tr>
										<tr><th>dtls</th><td>{{$book->dtls}} </td></tr>
										<tr><th>img</th><td>{{$book->img}} </td></tr>
										<tr><th>capacity</th><td>{{$book->capacity}} </td></tr>
										<tr><th>inst_users_id</th><td>{{$book->inst_users_id}} </td></tr>
										<tr><th>type</th><td>{{$book->type}} </td></tr>
										<tr><th>firstname</th><td>{{$book->firstname}} </td></tr>
										<tr><th>lastname</th><td>{{$book->lastname}} </td></tr>
										<tr><th>email</th><td>{{$book->email}} </td></tr>
										<tr><th>email_verified_at</th><td>{{$book->email_verified_at}} </td></tr>
										<tr><th>password</th><td>{{$book->password}} </td></tr>
										<tr><th>life</th><td>{{$book->life}} </td></tr>
										<tr><th>remember_token</th><td>{{$book->remember_token}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    