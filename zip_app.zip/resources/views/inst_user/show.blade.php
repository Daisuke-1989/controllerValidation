
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">inst_user {{ $inst_user-> }}</div>
                            <div class="panel-body">

                                <a href="{{ url("inst_user") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("inst_user") ."/". $inst_user-> . "/edit" }}" title="Edit inst_user"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/inst_user/{{ $inst_user-> }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$inst_user->id}} </td></tr>
										<tr><th>inst_id</th><td>{{$inst_user->inst_id}} </td></tr>
										<tr><th>j_title</th><td>{{$inst_user->j_title}} </td></tr>
										<tr><th>dept</th><td>{{$inst_user->dept}} </td></tr>
										<tr><th>type</th><td>{{$inst_user->type}} </td></tr>
										<tr><th>firstname</th><td>{{$inst_user->firstname}} </td></tr>
										<tr><th>lastname</th><td>{{$inst_user->lastname}} </td></tr>
										<tr><th>email</th><td>{{$inst_user->email}} </td></tr>
										<tr><th>email_verified_at</th><td>{{$inst_user->email_verified_at}} </td></tr>
										<tr><th>password</th><td>{{$inst_user->password}} </td></tr>
										<tr><th>life</th><td>{{$inst_user->life}} </td></tr>
										<tr><th>remember_token</th><td>{{$inst_user->remember_token}} </td></tr>
										<tr><th>inst_name</th><td>{{$inst_user->inst_name}} </td></tr>
										<tr><th>nations_id</th><td>{{$inst_user->nations_id}} </td></tr>
										<tr><th>life</th><td>{{$inst_user->life}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    