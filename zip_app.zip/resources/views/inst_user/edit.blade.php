
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">Edit inst_user #{{ $inst_user-> }}</div>
                            <div class="panel-body">
                                <a href="{{ url("inst_user") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <br />
                                <br />

                            @if ($errors->any())
                                <ul class="alert alert-danger">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            @endif
    
                            <form method="POST" action="/inst_user/{{ $inst_user-> }}" class="form-horizontal">
                                        {{ csrf_field() }}
                                        {{ method_field("PUT") }}
            
										<div class="form-group">
                                            <label for="id" class="col-md-4 control-label">id: </label>
                                            <div class="col-md-6">
                                                <input class="form-control" required="required" name="id" type="text" id="id" value="{{$inst_user->id}}">
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label for="inst_id" class="col-md-4 control-label">inst_id: </label>
                                            <div class="col-md-6">
                                                <input class="form-control" required="required" name="inst_id" type="text" id="inst_id" value="{{$inst_user->inst_id}}">
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label for="j_title" class="col-md-4 control-label">j_title: </label>
                                            <div class="col-md-6">
                                                <input class="form-control" required="required" name="j_title" type="text" id="j_title" value="{{$inst_user->j_title}}">
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label for="dept" class="col-md-4 control-label">dept: </label>
                                            <div class="col-md-6">
                                                <input class="form-control" required="required" name="dept" type="text" id="dept" value="{{$inst_user->dept}}">
                                            </div>
                                        </div>
               
                                    <div class="form-group">
                                        <div class="col-md-offset-4 col-md-4">
                                            <input class="btn btn-primary" type="submit" value="Update">
                                        </div>
                                    </div>   
                                </form>
                                

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    