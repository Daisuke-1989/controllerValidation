
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">inst {{ $inst->id }}</div>
                            <div class="panel-body">

                                <a href="{{ url("inst") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("inst") ."/". $inst->id . "/edit" }}" title="Edit inst"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/inst/{{ $inst->id }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$inst->id}} </td></tr>
										<tr><th>inst_name</th><td>{{$inst->inst_name}} </td></tr>
										<tr><th>nations_id</th><td>{{$inst->nations_id}} </td></tr>
										<tr><th>life</th><td>{{$inst->life}} </td></tr>
										<tr><th>region</th><td>{{$inst->region}} </td></tr>
										<tr><th>country</th><td>{{$inst->country}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    