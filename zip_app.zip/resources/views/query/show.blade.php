
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">query {{ $query->id }}</div>
                            <div class="panel-body">

                                <a href="{{ url("query") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("query") ."/". $query->id . "/edit" }}" title="Edit query"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/query/{{ $query->id }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$query->id}} </td></tr>
										<tr><th>events_id</th><td>{{$query->events_id}} </td></tr>
										<tr><th>terms_id</th><td>{{$query->terms_id}} </td></tr>
										<tr><th>students_id</th><td>{{$query->students_id}} </td></tr>
										<tr><th>dtls</th><td>{{$query->dtls}} </td></tr>
										<tr><th>title</th><td>{{$query->title}} </td></tr>
										<tr><th>insts_id</th><td>{{$query->insts_id}} </td></tr>
										<tr><th>date</th><td>{{$query->date}} </td></tr>
										<tr><th>start_time</th><td>{{$query->start_time}} </td></tr>
										<tr><th>end_time</th><td>{{$query->end_time}} </td></tr>
										<tr><th>dtls</th><td>{{$query->dtls}} </td></tr>
										<tr><th>img</th><td>{{$query->img}} </td></tr>
										<tr><th>capacity</th><td>{{$query->capacity}} </td></tr>
										<tr><th>inst_users_id</th><td>{{$query->inst_users_id}} </td></tr>
										<tr><th>type</th><td>{{$query->type}} </td></tr>
										<tr><th>firstname</th><td>{{$query->firstname}} </td></tr>
										<tr><th>lastname</th><td>{{$query->lastname}} </td></tr>
										<tr><th>email</th><td>{{$query->email}} </td></tr>
										<tr><th>email_verified_at</th><td>{{$query->email_verified_at}} </td></tr>
										<tr><th>password</th><td>{{$query->password}} </td></tr>
										<tr><th>life</th><td>{{$query->life}} </td></tr>
										<tr><th>remember_token</th><td>{{$query->remember_token}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    