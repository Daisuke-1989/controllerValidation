
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">student</div>
                            <div class="panel-body">
                            
                            
                                <a href="{{ url("student/create") }}" class="btn btn-success btn-sm" title="Add New student">
                                    Add New
                                </a>

                                <form method="GET" action="{{ url("student") }}" accept-charset="UTF-8" class="navbar-form navbar-right" role="search">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="search" placeholder="Search...">
                                        <span class="input-group-btn">
                                            <button class="btn btn-info" type="submit">
                                                <span>Search</span>
                                            </button>
                                        </span>
                                    </div>
                                </form>


                                <br/>
                                <br/>
                                
                                
                                <div class="table-responsive">
                                    <table class="table table-borderless">
                                        <thead>
                                            <tr><th>id</th><th>nations_id</th><th>year</th><th>type</th><th>firstname</th><th>lastname</th><th>email</th><th>email_verified_at</th><th>password</th><th>life</th><th>remember_token</th><th>region</th><th>country</th></tr>
                                        </thead>
                                        <tbody>
                                        @foreach($student as $item)
                                    
                                    <tr>

                                            <td>{{ $item->id}} </td>

                                            <td>{{ $item->nations_id}} </td>

                                            <td>{{ $item->year}} </td>

                                                    <td>{{ $item->type}} </td>

                                                    <td>{{ $item->firstname}} </td>

                                                    <td>{{ $item->lastname}} </td>

                                                    <td>{{ $item->email}} </td>

                                                    <td>{{ $item->email_verified_at}} </td>

                                                    <td>{{ $item->password}} </td>

                                                    <td>{{ $item->life}} </td>

                                                    <td>{{ $item->remember_token}} </td>

                                                    <td>{{ $item->region}} </td>

                                                    <td>{{ $item->country}} </td>
  
                                                <td><a href="{{ url("/student/" . $item->) }}" title="View student"><button class="btn btn-info btn-xs">View</button></a></td>
                                                <td><a href="{{ url("/student/" . $item-> . "/edit") }}" title="Edit student"><button class="btn btn-primary btn-xs">Edit</button></a></td>
                                                <td>
                                                    <form method="POST" action="/student/{{ $item-> }}" class="form-horizontal" style="display:inline;">
                                                        {{ csrf_field() }}
                                                        
                                                        {{ method_field("DELETE") }}
                                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                                        Delete
                                                        </button>    
                                                    </form>
                                                   </td>
                                              </tr>

                                        @endforeach
                                        </tbody>
                                    </table>
                                    <div class="pagination-wrapper"> {!! $student->appends(["search" => Request::get("search")])->render() !!} </div>
                                </div>
                                

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    