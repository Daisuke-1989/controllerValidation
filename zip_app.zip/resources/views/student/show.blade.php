
        @extends("layouts.app")
        @section("content")
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">student {{ $student-> }}</div>
                            <div class="panel-body">

                                <a href="{{ url("student") }}" title="Back"><button class="btn btn-warning btn-xs">Back</button></a>
                                <a href="{{ url("student") ."/". $student-> . "/edit" }}" title="Edit student"><button class="btn btn-primary btn-xs">Edit</button></a>
                                <form method="POST" action="/student/{{ $student-> }}" class="form-horizontal" style="display:inline;">
                                        {{ csrf_field() }}
                                        {{ method_field("delete") }}
                                        <button type="submit" class="btn btn-danger btn-xs" title="Delete User" onclick="return confirm('Confirm delete')">
                                        Delete
                                        </button>    
                            </form>
                            <br/>
                            <br/>
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
										<tr><th>id</th><td>{{$student->id}} </td></tr>
										<tr><th>nations_id</th><td>{{$student->nations_id}} </td></tr>
										<tr><th>year</th><td>{{$student->year}} </td></tr>
										<tr><th>type</th><td>{{$student->type}} </td></tr>
										<tr><th>firstname</th><td>{{$student->firstname}} </td></tr>
										<tr><th>lastname</th><td>{{$student->lastname}} </td></tr>
										<tr><th>email</th><td>{{$student->email}} </td></tr>
										<tr><th>email_verified_at</th><td>{{$student->email_verified_at}} </td></tr>
										<tr><th>password</th><td>{{$student->password}} </td></tr>
										<tr><th>life</th><td>{{$student->life}} </td></tr>
										<tr><th>remember_token</th><td>{{$student->remember_token}} </td></tr>
										<tr><th>region</th><td>{{$student->region}} </td></tr>
										<tr><th>country</th><td>{{$student->country}} </td></tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endsection
    